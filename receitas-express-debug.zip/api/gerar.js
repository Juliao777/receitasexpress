
const fetch = require('node-fetch');

module.exports = async (req, res) => {
  try {
    const { ingredientes } = req.body;

    const prompt = `Com os ingredientes: ${ingredientes}, crie uma receita simples com nome da receita, modo de preparo e tempo aproximado.`;

    console.log("🟢 Enviando prompt:", prompt);

    const resposta = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7
      })
    });

    const dados = await resposta.json();
    console.log("🟢 Resposta da API:", dados);

    if (!dados.choices || !dados.choices[0]) {
      throw new Error("Resposta inesperada da OpenAI");
    }

    res.status(200).json({ receita: dados.choices[0].message.content });
  } catch (erro) {
    console.error("🔴 Erro na função gerar.js:", erro);
    res.status(500).json({ erro: "Erro ao gerar receita." });
  }
};
